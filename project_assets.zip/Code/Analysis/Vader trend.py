import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("shopee_reviews_cleaned.csv")

df['reviewDate'] = pd.to_datetime(df['reviewDate'], errors='coerce')
df['YearMonth'] = df['reviewDate'].dt.to_period('M').astype(str)

sns.set(style='whitegrid')
plt.rcParams['font.family'] = 'Arial'

rating_trend = df.groupby(['YearMonth', 'Sentiment Label (from Rating)']).size().reset_index(name='count')
rating_total = df.groupby('YearMonth').size().reset_index(name='total')
rating_trend = rating_trend.merge(rating_total, on='YearMonth')
rating_trend['percentage'] = (rating_trend['count'] / rating_trend['total']) * 100

plt.figure(figsize=(12, 6))
sns.lineplot(data=rating_trend, x='YearMonth', y='percentage', hue='Sentiment Label (from Rating)', marker='o')
plt.title("Figure 4.3: Monthly Trend Chart of Emotional State Based on Ratings", fontsize=14)
plt.xlabel("Month")
plt.ylabel("Emotional Proportion (%)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("figure_4_3_rating_trend.png")
plt.show()


vader_trend = df.groupby(['YearMonth', 'VADER Label']).size().reset_index(name='count')
vader_total = df.groupby('YearMonth').size().reset_index(name='total')
vader_trend = vader_trend.merge(vader_total, on='YearMonth')
vader_trend['percentage'] = (vader_trend['count'] / vader_trend['total']) * 100

plt.figure(figsize=(12, 6))
sns.lineplot(data=vader_trend, x='YearMonth', y='percentage', hue='VADER Label', marker='o')
plt.title("Figure 4.4: Monthly Trend Chart of Emotions Based on VADER", fontsize=14)
plt.xlabel("Month")
plt.ylabel("Emotional Proportion (%)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("figure_4_4_vader_trend.png")
plt.show()
