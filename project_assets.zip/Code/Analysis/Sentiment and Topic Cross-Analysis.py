import pandas as pd
import gensim
from gensim import corpora
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("shopee_reviews_cleaned.csv")

valid_mask = df['Cleaned Review Text'].notna()
valid_texts = df.loc[valid_mask, 'Cleaned Review Text'].apply(lambda x: x.split()).tolist()

dictionary = corpora.Dictionary(valid_texts)
corpus = [dictionary.doc2bow(text) for text in valid_texts]

lda_model = gensim.models.LdaModel(
    corpus=corpus,
    id2word=dictionary,
    num_topics=8,
    passes=10,
    random_state=42
)

topic_labels = []
for doc_bow in corpus:
    topic_probs = lda_model.get_document_topics(doc_bow)
    topic = max(topic_probs, key=lambda x: x[1])[0] if topic_probs else None
    topic_labels.append(topic)

df['LDA Topic'] = pd.NA
df.loc[valid_mask, 'LDA Topic'] = topic_labels
df['LDA Topic'] = df['LDA Topic'].astype('Int64')

# --------------------
# 📊 Cross-analysis table output
# --------------------

topic_sentiment_table = pd.crosstab(df['LDA Topic'], df['VADER Label'], normalize='index') * 100
print("\n📊 Sentiment Distribution by LDA Topic (%):")
print(topic_sentiment_table.round(2))

# --------------------
# 📈 Heatmap visualization
# --------------------
plt.figure(figsize=(10, 6))
sns.heatmap(topic_sentiment_table, annot=True, cmap="YlGnBu", fmt=".1f")
plt.title("LDA Topic vs VADER Sentiment (%)", fontsize=14)
plt.ylabel("LDA Topic")
plt.xlabel("VADER Sentiment Label")
plt.tight_layout()
plt.savefig("topic_sentiment_heatmap.png")
plt.show()


