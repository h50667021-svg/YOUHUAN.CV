import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.family'] = 'Arial'
df = pd.read_csv("shopee_reviews_cleaned.csv")
df['Month'] = pd.to_datetime(df['Month'], errors='coerce')
df['Month_Str'] = df['Month'].dt.strftime('%Y-%m')
plt.figure(figsize=(8, 5))
sns.boxplot(x='score', y='VADER Sentiment', data=df, palette='coolwarm')
plt.title('Boxplot of VADER Sentiment by Rating Score')
plt.xlabel('Rating Score')
plt.ylabel('VADER Sentiment Score')
plt.tight_layout()
plt.savefig("boxplot_score_vs_vader.png")
plt.show()
