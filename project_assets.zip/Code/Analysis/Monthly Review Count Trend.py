import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("shopee_reviews_cleaned.csv")
df['Month'] = pd.to_datetime(df['Month'].astype(str))


monthly_counts = df.groupby(df['Month']).size()

plt.figure(figsize=(8, 4))
monthly_counts.plot(marker='o')
plt.title('Monthly Review Count Trend')
plt.xlabel('Month')
plt.ylabel('Number of Reviews')
plt.grid(True)
plt.tight_layout()
plt.savefig("monthly_trend.png")
plt.show()
