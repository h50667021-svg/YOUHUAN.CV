import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.family'] = 'Arial'
df = pd.read_csv("shopee_reviews_cleaned.csv")
df['Month'] = pd.to_datetime(df['Month'], errors='coerce')
df['Month_Str'] = df['Month'].dt.strftime('%Y-%m')
monthly_avg_score = df.groupby(df['Month'])['score'].mean()

plt.figure(figsize=(8, 4))
monthly_avg_score.plot(marker='o', color='green')
plt.title("Average Monthly Rating Score")
plt.xlabel("Month")
plt.ylabel("Average Score")
plt.grid(True)
plt.tight_layout()
plt.savefig("monthly_avg_score.png")
plt.show()

