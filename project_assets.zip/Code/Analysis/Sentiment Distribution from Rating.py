import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


df = pd.read_csv("shopee_reviews_cleaned.csv")

plt.figure(figsize=(6, 4))
sns.countplot(x='Sentiment Label (from Rating)', data=df, palette='Set2')
plt.title('Sentiment Distribution from Rating')
plt.xlabel('Sentiment Label')
plt.ylabel('Number of Reviews')
plt.tight_layout()
plt.savefig("sentiment_bar_rating.png")
plt.show()



