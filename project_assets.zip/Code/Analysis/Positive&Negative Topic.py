import pandas as pd
from wordcloud import WordCloud
import matplotlib.pyplot as plt

df = pd.read_csv("shopee_reviews_cleaned.csv")
df['Sentiment Label (from Rating)'] = df['Sentiment Label (from Rating)'].str.lower().str.strip()

print("Column Name：", df.columns.tolist())

positive_df = df[(df['Sentiment Label (from Rating)'] == 'positive') & (df['Cleaned Review Text'].notnull())]
if not positive_df.empty:
    positive_text = ' '.join(positive_df['Cleaned Review Text'])
    wordcloud_pos = WordCloud(width=800, height=400, background_color='white').generate(positive_text)

    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud_pos, interpolation='bilinear')
    plt.axis('off')
    plt.title('Figure 3.2 Positive Comment Word Cloud Chart')
    plt.savefig('positive_wordcloud.png')
    plt.show()
else:
    print("⚠️ No positive reviews were found, so Figure 3.2 cannot be generated.")

negative_df = df[(df['Sentiment Label (from Rating)'] == 'negative') & (df['Cleaned Review Text'].notnull())]
if not negative_df.empty:
    negative_text = ' '.join(negative_df['Cleaned Review Text'])
    wordcloud_neg = WordCloud(width=800, height=400, background_color='white').generate(negative_text)

    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud_neg, interpolation='bilinear')
    plt.axis('off')
    plt.title('Figure 3.3 Negative Comment Word Cloud Chart')
    plt.savefig('negative_wordcloud.png')
    plt.show()
else:
    print("⚠️ No negative comments were found, so Figure 3.3 cannot be generated.")
