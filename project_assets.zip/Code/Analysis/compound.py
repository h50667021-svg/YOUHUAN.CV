import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk

# nltk.download('vader_lexicon')

df = pd.read_csv("shopee_reviews_cleaned.csv")

sia = SentimentIntensityAnalyzer()

df['VADER Score'] = df['reviewText'].astype(str).apply(lambda x: sia.polarity_scores(x)['compound'])

def get_vader_label(score):
    if score >= 0.05:
        return 'positive'
    elif score <= -0.05:
        return 'negative'
    else:
        return 'neutral'

df['VADER Sentiment'] = df['VADER Score'].apply(get_vader_label)

vader_counts = df['VADER Sentiment'].value_counts()
vader_percent = df['VADER Sentiment'].value_counts(normalize=True) * 100

vader_summary = pd.DataFrame({
    'Number of comments': vader_counts,
    'Proportion (%)': vader_percent.round(2)
})

print("\n📊 Distribution table based on VADER sentiment analysis：")
print(vader_summary)

plt.figure(figsize=(6, 4))
sns.barplot(x=vader_summary.index, y='Number of comments', data=vader_summary.reset_index(), palette='pastel')
plt.title("VADER Sentiment Distribution")
plt.xlabel("Emotional Categories")
plt.ylabel("Number of comments")
plt.tight_layout()
plt.savefig("vader_sentiment_distribution.png")
plt.show()

