import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.family'] = 'Arial'
df = pd.read_csv("shopee_reviews_cleaned.csv")
df['Month'] = pd.to_datetime(df['Month'], errors='coerce')
df['Month_Str'] = df['Month'].dt.strftime('%Y-%m')
sentiment_table = pd.crosstab(df['Month_Str'], df['Sentiment Label (from Rating)'])
sentiment_table.plot(kind='bar', stacked=True, figsize=(10, 5), colormap='Set3')
plt.title("Monthly Sentiment Distribution (From Rating)")
plt.xlabel("Month")
plt.ylabel("Review Count")
plt.xticks(rotation=45)
plt.legend(title="Sentiment")
plt.tight_layout()
plt.savefig("monthly_stacked_sentiment.png")
plt.show()