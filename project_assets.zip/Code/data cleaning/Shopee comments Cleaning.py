import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('vader_lexicon')
df = pd.read_csv(r"D:\YOUHUAN\USM Course\web and social media#ABM503\assignment\OPTION1\data\shopee_play_reviews.csv")
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    tokens = text.split()
    stop_words = set(stopwords.words('english'))
    tokens = [w for w in tokens if w not in stop_words and len(w) > 2]
    return " ".join(tokens)
df['Cleaned Review Text'] = df['reviewText'].apply(clean_text)
def label_from_score(score):
    if score >= 4:
        return 'Positive'
    elif score == 3:
        return 'Neutral'
    else:
        return 'Negative'
df['Sentiment Label (from Rating)'] = df['score'].apply(label_from_score)
df['Month'] = pd.to_datetime(df['reviewDate']).dt.to_period('M')
sia = SentimentIntensityAnalyzer()
df['VADER Sentiment'] = df['Cleaned Review Text'].apply(lambda x: sia.polarity_scores(x)['compound'])
def vader_to_label(score):
    if score >= 0.05:
        return 'Positive'
    elif score <= -0.05:
        return 'Negative'
    else:
        return 'Neutral'
df['VADER Label'] = df['VADER Sentiment'].apply(vader_to_label)
df.to_csv("shopee_reviews_cleaned.csv", index=False, encoding='utf-8-sig')
print("✅ Data cleaning is complete and has been saved as shopee_reviews_cleaned.csv")
