import pandas as pd
import gensim
from gensim import corpora
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import pyLDAvis.gensim_models

df = pd.read_csv("shopee_reviews_cleaned.csv")

texts = df['Cleaned Review Text'].dropna().apply(lambda x: x.split()).tolist()
dictionary = corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts]

lda_model = gensim.models.ldamodel.LdaModel(corpus=corpus,
                                             id2word=dictionary,
                                             num_topics=8,
                                             random_state=42,
                                             passes=10,
                                             per_word_topics=True)

print("\n📌 Top Words per Topic:")
for i, topic in lda_model.show_topics(formatted=False):
    words = [word for word, _ in topic]
    print(f"🟣 Topic {i + 1}: {', '.join(words)}")

for i, topic in lda_model.show_topics(formatted=False):
    word_freq = {word: weight for word, weight in topic}
    wc = WordCloud(width=800, height=400, background_color='white').generate_from_frequencies(word_freq)
    plt.figure(figsize=(8, 4))
    plt.imshow(wc, interpolation='bilinear')
    plt.axis("off")
    plt.title(f"Topic {i + 1} WordCloud")
    plt.tight_layout()
    plt.savefig(f"topic_{i + 1}_wordcloud.png")
    plt.close()
print("✅ All the word clouds have been created!")
print("📊 Generating the interaction diagram... Please wait...")
import os
import tempfile
os.environ['JOBLIB_TEMP_FOLDER'] = tempfile.mkdtemp(prefix="lda_temp_", dir="C:/Temp")
vis = pyLDAvis.gensim_models.prepare(lda_model, corpus, dictionary)
pyLDAvis.save_html(vis, "shopee_lda_gensim_visualization.html")
print("✅ The visual graph has been saved as shopee_lda_gensim_visualization.html")


