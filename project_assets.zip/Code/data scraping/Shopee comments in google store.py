from google_play_scraper import reviews, Sort
import pandas as pd

def fetch_reviews(app_package_name, n_reviews=10000, lang='en', country='us'):
    all_reviews = []
    cursor = None
    while len(all_reviews) < n_reviews:
        revs, cursor = reviews(
            app_package_name,
            lang=lang,
            country=country,
            sort=Sort.NEWEST,
            count=200,
            continuation_token=cursor
        )
        all_reviews.extend(revs)
        if not cursor:
            break
    return all_reviews[:n_reviews]

package_name = "com.shopee.sg"

print("Starting to scrape Shopee reviews...")
data = fetch_reviews(package_name, n_reviews=10000)

df = pd.DataFrame([{
    'reviewId': r['reviewId'],
    'userName': r['userName'],
    'userImage': r['userImage'],
    'reviewText': r['content'],
    'score': r['score'],
    'thumbsUpCount': r['thumbsUpCount'],
    'reviewCreatedVersion': r.get('reviewCreatedVersion', ''),
    'reviewDate': r['at'],
    'replyContent': r.get('replyContent', ''),
    'repliedAt': r.get('repliedAt', ''),
} for r in data])

df.to_csv('shopee_play_reviews.csv', index=False, encoding='utf-8-sig')
print(f"✅ Successfully captured and saved {len(df)} comments to shopee_play_reviews.csv")













